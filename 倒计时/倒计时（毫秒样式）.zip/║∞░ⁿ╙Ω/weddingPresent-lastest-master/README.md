# 最新版的红包雨
> 暂时就做到这种程度了，有什么想法，可以联系我.
> 核心思想是将红包作为一个对象，每次点击红包，则能拿到这个对象。设计思路类似，获取dom元素。

## 运行
```bash
git clone git@github.com:superNever/weddingPresent-lastest.git
cd weddingPresent-lastest&&npm install
npm run start
```

